const STORAGE_KEY = 'gw-study-spot-tracker-v1';
const starterSpots = [
  {id:'spot-1',name:'Library Study Area',area:'Campus library',noise:'Quiet',seats:'Limited',outlets:true,updated:'Example listing'},
  {id:'spot-2',name:'Student Lounge',area:'Student center',noise:'Lively',seats:'Available',outlets:true,updated:'Example listing'},
  {id:'spot-3',name:'Open Study Tables',area:'Academic building',noise:'Moderate',seats:'Available',outlets:false,updated:'Example listing'}
];
const $ = selector => document.querySelector(selector);
const spotList=$('#spot-list'), spotCount=$('#spot-count'), emptyState=$('#empty-state');
const searchInput=$('#search-input'), noiseFilter=$('#noise-filter'), seatFilter=$('#seat-filter'), outletFilter=$('#outlet-filter');
const spotForm=$('#spot-form');
let spots=loadSpots();
function loadSpots(){try{const saved=localStorage.getItem(STORAGE_KEY);return saved?JSON.parse(saved):starterSpots}catch{return starterSpots}}
function saveSpots(){localStorage.setItem(STORAGE_KEY,JSON.stringify(spots))}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function noiseClass(noise){return noise==='Quiet'?'tag-quiet':noise==='Lively'?'tag-lively':'tag-moderate'}
function renderSpots(){
  const search=searchInput.value.trim().toLowerCase(), noise=noiseFilter.value, seats=seatFilter.value, needsOutlets=outletFilter.checked;
  const visible=spots.filter(s=>`${s.name} ${s.area}`.toLowerCase().includes(search)&&(noise==='all'||s.noise===noise)&&(seats==='all'||s.seats===seats)&&(!needsOutlets||s.outlets));
  spotCount.textContent=visible.length;emptyState.classList.toggle('hidden',visible.length!==0);
  spotList.innerHTML=visible.map(s=>`<article class="card"><div class="card-top"><div><h3>${escapeHtml(s.name)}</h3><div class="area">${escapeHtml(s.area)}</div></div><span class="tag ${noiseClass(s.noise)}">${escapeHtml(s.noise)}</span></div><div class="chips"><span class="chip">Seats: ${escapeHtml(s.seats)}</span><span class="chip">${s.outlets?'🔌 Outlets':'No outlets listed'}</span></div><div class="card-bottom"><label>Update noise level<select data-id="${s.id}" data-field="noise">${['Quiet','Moderate','Lively'].map(v=>`<option ${s.noise===v?'selected':''}>${v}</option>`).join('')}</select></label><label>Update seating<select data-id="${s.id}" data-field="seats">${['Available','Limited','Full'].map(v=>`<option ${s.seats===v?'selected':''}>${v}</option>`).join('')}</select></label><div class="card-actions"><span class="updated">${escapeHtml(s.updated||'Not updated yet')}</span><button class="small" type="button" data-delete="${s.id}">Remove</button></div></div></article>`).join('');
}
function updateSpot(id,field,value){spots=spots.map(s=>s.id===id?{...s,[field]:value,updated:'Updated just now'}:s);saveSpots();renderSpots()}
[searchInput,noiseFilter,seatFilter,outletFilter].forEach(el=>el.addEventListener(el===searchInput?'input':'change',renderSpots));
$('#show-form-button').addEventListener('click',()=>{spotForm.classList.remove('hidden');$('#new-name').focus()});
$('#cancel-form-button').addEventListener('click',()=>{spotForm.reset();spotForm.classList.add('hidden')});
spotForm.addEventListener('submit',event=>{event.preventDefault();const name=$('#new-name').value.trim(),area=$('#new-area').value.trim();if(!name||!area)return;spots.unshift({id:`spot-${Date.now()}`,name,area,noise:$('#new-noise').value,seats:$('#new-seats').value,outlets:$('#new-outlets').checked,updated:'Added just now'});saveSpots();spotForm.reset();spotForm.classList.add('hidden');searchInput.value='';noiseFilter.value='all';seatFilter.value='all';outletFilter.checked=false;renderSpots()});
spotList.addEventListener('change',event=>{const el=event.target;if(el.matches('select[data-id][data-field]'))updateSpot(el.dataset.id,el.dataset.field,el.value)});
spotList.addEventListener('click',event=>{const button=event.target.closest('button[data-delete]');if(!button)return;spots=spots.filter(s=>s.id!==button.dataset.delete);saveSpots();renderSpots()});
renderSpots();
